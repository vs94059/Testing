package pages;

import helper.Browser;
import pages.shared.Page;

/**
 * Created by opantsjoha on 02/07/2017.
 */
public class HomePage extends Page {

    public HomePage(Browser browser) {
        super(browser);
    }

}
